#!/usr/bin/env python3
"""Generate UIKit-only runtime localization rules from the GTA V Port Swift UI glossary."""
import json, re, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent.parent

def obj(s):
    # Objective-C Unicode string literal; json handles backslashes and line breaks.
    return '@' + json.dumps(s, ensure_ascii=False)

def tokenize(s):
    # Model only Swift interpolation (not its expression text). Keep escaped string literal text.
    toks=[]; cur=''; i=0
    while i < len(s):
        if s.startswith('\\(', i):
            if cur: toks.append(('text', cur)); cur=''
            i+=2; depth=1; quoted=False; escaped=False
            while i < len(s) and depth:
                c=s[i]
                if quoted:
                    if escaped: escaped=False
                    elif c=='\\': escaped=True
                    elif c=='"': quoted=False
                else:
                    if c=='"': quoted=True
                    elif c=='(': depth+=1
                    elif c==')': depth-=1
                i+=1
            if depth: raise ValueError('Unclosed interpolation: '+s)
            toks.append(('var',None)); continue
        # Swift string escapes that affect the final rendered UI.
        if s.startswith('\\n',i): cur+='\n'; i+=2;continue
        if s.startswith('\\t',i): cur+='\t'; i+=2;continue
        if s.startswith('\\"',i): cur+='"'; i+=2;continue
        if s.startswith('\\\\',i): cur+='\\'; i+=2;continue
        m=re.match(r'%([-+ #0]*\d*(?:\.\d+)?[diuoxXfFeEgGaAcCsSp@])',s[i:])
        if m:
            if cur:toks.append(('text',cur));cur=''
            toks.append(('var',None));i+=len(m.group());continue
        cur+=s[i]; i+=1
    if cur:toks.append(('text',cur))
    return toks

def literal(ts): return ''.join(v for t,v in ts if t=='text')

raw=[]
for lineno,line in enumerate((HERE/'src'/'zh_CN.tsv').read_text().splitlines(),1):
    if not line or line.startswith('#'):continue
    if '|||' not in line: raise ValueError(lineno)
    src,dst=line.split('|||',1)
    a,b=tokenize(src),tokenize(dst)
    if sum(t=='var' for t,_ in a)!=sum(t=='var' for t,_ in b):
        print('Skipping incompatible interpolation',lineno,src,file=sys.stderr);continue
    raw.append((src,dst,a,b))

exact={};patterns=[];fragments=[]
for src,dst,a,b in raw:
    if not any(t=='var' for t,_ in a):
        key=literal(a);value=literal(b)
        if key in exact and exact[key]!=value: print('Duplicate conflict',key,file=sys.stderr)
        exact[key]=value
        # Sentences intended for concatenation as prefixes/suffixes.
        if key.strip() and (key[:1].isspace() or key[-1:].isspace() or key.startswith(('.',':','·','\n'))):
            fragments.append((key,value))
    else:
        idx=0;rx='';subst='';
        for t,v in a:
            if t=='var': idx+=1;rx+='(.*?)'
            else:rx+=re.escape(v)
        idx2=0
        for t,v in b:
            if t=='var': idx2+=1;subst+='$'+str(idx2)
            else:subst+=v.replace('\\','\\\\').replace('$','\\$')
        full=('^'+rx+'$',subst)
        patterns.append((full[0],full[1],src))
        # E.g. a status suffix, appended to a larger message.
        if literal(a).startswith((' ', '\n','.')) or (a[0][0]=='text' and a[0][1].startswith(' ')):
            fragments.append((rx,subst,True))

# Also localize mode and preset names when followed by ' (playing now)' etc.
prefixes=['Story mode','Sandbox','Battery','Performance','Balanced','Quality','Ultra','Max']
for pre in prefixes:
    if pre in exact:
        fragments.append((r'^'+re.escape(pre)+r'(?=[\s·(（])', exact[pre], True))

head = '''// Generated from src/zh_CN.tsv — don't edit by hand. No game code is modified.\n#import <Foundation/Foundation.h>\nstatic NSDictionary<NSString *, NSString *> *ZHExactRules(void) { return @{\n'''
for k,v in exact.items():head+='  '+obj(k)+': '+obj(v)+',\n'
head+='}; }\n\nstatic NSArray<NSArray<NSString *> *> *ZHPatternData(void) { return @[\n'
for rx,dst,src in sorted(patterns,key=lambda r:-len(r[2])):
    head+='  @['+obj(rx)+', '+obj(dst)+'],\n'
head+=']; }\n\nstatic NSArray<NSArray<NSString *> *> *ZHFragmentData(void) { return @[\n'
for item in sorted(fragments,key=lambda r:-len(r[0])):
    rx = item[0] if len(item)==3 else re.escape(item[0])
    dst=item[1]
    head+='  @['+obj(rx)+', '+obj(dst)+'],\n'
head+=']; }\n'
(HERE/'src'/'ZHGeneratedRules.h').write_text(head)
print(f'Generated {len(exact)} exact + {len(patterns)} interpolated + {len(fragments)} fragment entries from {len(raw)} translations.')
# Verify example format substitutions by modeling regex on Swift-interpolated values.
assert exact['Play']=='开始游戏'
assert next((dst for rx,dst,src in patterns if src=='Game files: \\(title). \\(detail)'),None) is not None
