# GTA V iOS Port 简体中文 dylib

基于 [kevinerikjs/gta5-ios-port](https://github.com/kevinerikjs/gta5-ios-port) 的 Swift 界面文本制作。**不会修改游戏程序的 Swift、WASM 或游戏资产文件**。

## 覆盖范围

- 首页、故事/沙盒模式、画质、帧率、陀螺仪、手柄、触屏设置
- 游戏文件检查、压缩包导入、下载进度及错误消息
- iOS 弹窗、导航标题、按钮及可见的 UIKit 标签

词库包含 **353** 条英文→简体中文映射；动态模板处理 Swift 插值、下载进度和数字参数。部分界面可能因为使用自绘引擎或非 UIKit 文本而保持英文。GTA V 游戏内部字幕/菜单不在此 dylib 的保证范围内。

## 构建

把本目录提交到自己的 GitHub 仓库的 `gta5-ios-zh-dylib` 分支：`.github/workflows/build-dylib.yml` 会在 macOS 15 的 GitHub Actions 中构建 `arm64` / iOS 17+ 的动态库。Artifacts 中下载 `GTA5ZH.dylib`。

不需要上传 GTA V 游戏文件。这里只编译独立 UI 汉化 dylib。

## 注入

`GTA5ZH.dylib` 不是 IPA，不能独立安装。需要使用支持动态库注入的 IPA 修改工具将它添加到 GTA V Port 应用的 `Frameworks/` 内，并将 app 可执行文件的依赖设置为 `@executable_path/Frameworks/GTA5ZH.dylib`。随后**重新签名**整个 IPA 后安装。越狱环境也可以通过合适的加载机制注入。

- 目标可执行文件：`PlayGTA5Native`
- 原项目包 ID：`io.github.playgta5ios.app`（重新签名可能改变包 ID，因而同时检查可执行文件名）
- 适用 iOS 版本：17+，arm64
- 仅替换界面显示文字，不修改存档、网络或游戏引擎逻辑；按钮原始标题状态保留，避免影响游戏对 `title(for:)` 的读取。

## 局限和自检

没有将实际 IPA 载入 iOS 设备进行视觉回归测试。用户界面里非 UIKit 绘制的文本可能无法通过这种运行时覆盖汉化。动态库必须成功被目标进程加载，才能产生效果。可在设备日志中查找 `[GTA5ZH]` 确认。

对问题和遗漏翻译请修改 `src/zh_CN.tsv`，运行 `python3 tools/generate.py` 重新生成 `src/ZHGeneratedRules.h`，再构建。
