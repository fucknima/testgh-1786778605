// GTA V Port Simplified Chinese dynamic localization
// Hooks ONLY UIKit presentation APIs; doesn't patch, inspect, or replace the game engine.
// Target: io.github.playgta5ios.app / PlayGTA5Native, iOS 17+, arm64.
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "ZHGeneratedRules.h"

static NSDictionary<NSString *, NSString *> *zh_exact;
static NSArray<NSArray *> *zh_fullPatterns;
static NSArray<NSArray *> *zh_fragments;
static NSCache<NSString *, NSString *> *zh_cache;

static NSArray<NSArray *> *zh_compile(NSArray<NSArray<NSString *> *> *input) {
    NSMutableArray *out = [NSMutableArray arrayWithCapacity:input.count];
    for (NSArray<NSString *> *pair in input) {
        NSError *err = nil;
        NSRegularExpression *pattern = [NSRegularExpression regularExpressionWithPattern:pair[0]
            options:NSRegularExpressionDotMatchesLineSeparators error:&err];
        if (pattern != nil) [out addObject:@[pattern, pair[1]]];
        else NSLog(@"[GTA5ZH] Invalid regex %@ (%@)", pair[0], err);
    }
    return [out copy];
}

static void zh_init(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        zh_exact = ZHExactRules();
        zh_fullPatterns = zh_compile(ZHPatternData());
        zh_fragments = zh_compile(ZHFragmentData());
        zh_cache = [NSCache new];
        zh_cache.countLimit = 1500;
    });
}

static NSString *zh_localize(NSString *source) {
    if (![source isKindOfClass:[NSString class]] || source.length == 0) return source;
    zh_init();
    NSString *hit = [zh_cache objectForKey:source];
    if (hit != nil) return hit;
    NSString *result = zh_exact[source];
    if (result == nil) {
        result = source;
        for (NSArray *r in zh_fullPatterns) {
            NSRegularExpression *pattern = r[0];
            if ([pattern firstMatchInString:result options:0 range:NSMakeRange(0, result.length)]) {
                result = [pattern stringByReplacingMatchesInString:result options:0
                    range:NSMakeRange(0, result.length) withTemplate:r[1]];
                break;
            }
        }
        // Status messages assembled with += need suffix / prefix translation as well.
        for (NSArray *r in zh_fragments) {
            NSRegularExpression *pattern = r[0];
            result = [pattern stringByReplacingMatchesInString:result options:0
                range:NSMakeRange(0, result.length) withTemplate:r[1]];
        }
    }
    [zh_cache setObject:result forKey:source];
    return result;
}

static NSAttributedString *zh_attributed(NSAttributedString *source) {
    if (![source isKindOfClass:[NSAttributedString class]] || source.length == 0) return source;
    NSString *original = source.string;
    NSString *translated = zh_localize(original);
    if ([original isEqualToString:translated]) return source;
    // Keep the text attributes (font, color, paragraph style). For localized strings with
    // a different length, copy the first run; the GTA V launcher uses plain title runs.
    NSDictionary *attributes = [source attributesAtIndex:0 effectiveRange:NULL];
    return [[NSAttributedString alloc] initWithString:translated attributes:attributes];
}

static void zh_swizzle(Class cls, SEL original, SEL replacement) {
    Method a = class_getInstanceMethod(cls, original);
    Method b = class_getInstanceMethod(cls, replacement);
    if (!a || !b) { NSLog(@"[GTA5ZH] Missing selector %@ on %@", NSStringFromSelector(original), cls); return; }
    method_exchangeImplementations(a, b);
}

static void zh_swizzle_class(Class cls, SEL original, SEL replacement) {
    Method a = class_getClassMethod(cls, original);
    Method b = class_getClassMethod(cls, replacement);
    if (a && b) method_exchangeImplementations(a, b);
}

@interface UILabel (GTA5ZH)
@end
@implementation UILabel (GTA5ZH)
- (void)gta5zh_setText:(NSString *)text { [self gta5zh_setText:zh_localize(text)]; }
- (void)gta5zh_setAttributedText:(NSAttributedString *)text { [self gta5zh_setAttributedText:zh_attributed(text)]; }
@end

@interface UIBarButtonItem (GTA5ZH)
@end
@implementation UIBarButtonItem (GTA5ZH)
- (void)gta5zh_setTitle:(NSString *)title { [self gta5zh_setTitle:zh_localize(title)]; }
- (instancetype)gta5zh_initWithTitle:(NSString *)title style:(UIBarButtonItemStyle)style target:(id)target action:(SEL)action {
    return [self gta5zh_initWithTitle:zh_localize(title) style:style target:target action:action];
}
@end

@interface UIViewController (GTA5ZH)
@end
@implementation UIViewController (GTA5ZH)
- (void)gta5zh_setTitle:(NSString *)title { [self gta5zh_setTitle:zh_localize(title)]; }
@end

@interface UINavigationItem (GTA5ZH)
@end
@implementation UINavigationItem (GTA5ZH)
- (void)gta5zh_setTitle:(NSString *)title { [self gta5zh_setTitle:zh_localize(title)]; }
@end

@interface UITextField (GTA5ZH)
@end
@implementation UITextField (GTA5ZH)
- (void)gta5zh_setPlaceholder:(NSString *)placeholder { [self gta5zh_setPlaceholder:zh_localize(placeholder)]; }
@end

@interface UITextView (GTA5ZH)
@end
@implementation UITextView (GTA5ZH)
- (void)gta5zh_setText:(NSString *)text { [self gta5zh_setText:zh_localize(text)]; }
- (void)gta5zh_setAttributedText:(NSAttributedString *)text { [self gta5zh_setAttributedText:zh_attributed(text)]; }
@end

@interface UISearchBar (GTA5ZH)
@end
@implementation UISearchBar (GTA5ZH)
- (void)gta5zh_setPlaceholder:(NSString *)placeholder { [self gta5zh_setPlaceholder:zh_localize(placeholder)]; }
@end

@interface UISegmentedControl (GTA5ZH)
@end
@implementation UISegmentedControl (GTA5ZH)
- (instancetype)gta5zh_initWithItems:(NSArray *)items {
    NSMutableArray *updated = [NSMutableArray arrayWithCapacity:items.count];
    for (id item in items) [updated addObject:[item isKindOfClass:[NSString class]] ? zh_localize(item) : item];
    return [self gta5zh_initWithItems:updated];
}
- (void)gta5zh_setTitle:(NSString *)title forSegmentAtIndex:(NSUInteger)index {
    [self gta5zh_setTitle:zh_localize(title) forSegmentAtIndex:index];
}
- (void)gta5zh_insertSegmentWithTitle:(NSString *)title atIndex:(NSUInteger)index animated:(BOOL)animated {
    [self gta5zh_insertSegmentWithTitle:zh_localize(title) atIndex:index animated:animated];
}
@end

@interface UIAlertController (GTA5ZH)
@end
@implementation UIAlertController (GTA5ZH)
+ (instancetype)gta5zh_alertControllerWithTitle:(NSString *)title message:(NSString *)message
    preferredStyle:(UIAlertControllerStyle)preferredStyle {
    return [self gta5zh_alertControllerWithTitle:zh_localize(title)
        message:zh_localize(message) preferredStyle:preferredStyle];
}
- (void)gta5zh_setMessage:(NSString *)message { [self gta5zh_setMessage:zh_localize(message)]; }
@end

@interface UIAlertAction (GTA5ZH)
@end
@implementation UIAlertAction (GTA5ZH)
+ (instancetype)gta5zh_actionWithTitle:(NSString *)title style:(UIAlertActionStyle)style handler:(void (^)(UIAlertAction *))handler {
    return [self gta5zh_actionWithTitle:zh_localize(title) style:style handler:handler];
}
@end

__attribute__((constructor)) static void GTA5ZHStart(void) {
    @autoreleasepool {
        NSString *exe = [NSBundle mainBundle].executablePath.lastPathComponent;
        NSString *bundleID = [NSBundle mainBundle].bundleIdentifier.lowercaseString ?: @"";
        if (![exe isEqualToString:@"PlayGTA5Native"] && [bundleID rangeOfString:@"playgta5ios"].location == NSNotFound) {
            return; // Do not alter other applications when injected into the wrong process.
        }
        zh_init();
        zh_swizzle([UILabel class], @selector(setText:), @selector(gta5zh_setText:));
        zh_swizzle([UILabel class], @selector(setAttributedText:), @selector(gta5zh_setAttributedText:));
        zh_swizzle([UITextView class], @selector(setText:), @selector(gta5zh_setText:));
        zh_swizzle([UITextView class], @selector(setAttributedText:), @selector(gta5zh_setAttributedText:));
        zh_swizzle([UITextField class], @selector(setPlaceholder:), @selector(gta5zh_setPlaceholder:));
        zh_swizzle([UISearchBar class], @selector(setPlaceholder:), @selector(gta5zh_setPlaceholder:));
        zh_swizzle([UIViewController class], @selector(setTitle:), @selector(gta5zh_setTitle:));
        zh_swizzle([UINavigationItem class], @selector(setTitle:), @selector(gta5zh_setTitle:));
        zh_swizzle([UIBarButtonItem class], @selector(setTitle:), @selector(gta5zh_setTitle:));
        zh_swizzle([UIBarButtonItem class], @selector(initWithTitle:style:target:action:), @selector(gta5zh_initWithTitle:style:target:action:));
        zh_swizzle([UISegmentedControl class], @selector(initWithItems:), @selector(gta5zh_initWithItems:));
        zh_swizzle([UISegmentedControl class], @selector(setTitle:forSegmentAtIndex:), @selector(gta5zh_setTitle:forSegmentAtIndex:));
        zh_swizzle([UISegmentedControl class], @selector(insertSegmentWithTitle:atIndex:animated:), @selector(gta5zh_insertSegmentWithTitle:atIndex:animated:));
        zh_swizzle_class([UIAlertController class], @selector(alertControllerWithTitle:message:preferredStyle:),
            @selector(gta5zh_alertControllerWithTitle:message:preferredStyle:));
        zh_swizzle([UIAlertController class], @selector(setMessage:), @selector(gta5zh_setMessage:));
        zh_swizzle_class([UIAlertAction class], @selector(actionWithTitle:style:handler:),
            @selector(gta5zh_actionWithTitle:style:handler:));
        NSLog(@"[GTA5ZH] Simplified Chinese UI localization loaded (%@)", exe);
    }
}
